import { Button } from "@/components/ui/button"
import {
  Facebook,
  Instagram,
  MessageCircle,
  Building2,
  Users,
  Shield,
  Heart,
  FileText,
  ShoppingCart,
  ArrowRight,
  Award,
  Target,
  CheckCircle,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"
import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0b3b49] to-black"></div>

        <div className="container mx-auto px-4 relative z-10 text-center">
          <div className="max-w-4xl mx-auto">
            {/* Logo Principal */}
            <div className="mb-8 animate-fade-in">
              <div className="mb-6">
                <Image
                  src="/images/Logotipo_7-removebg-preview.png"
                  alt="Theodoro Melo Andrade Costa Logo"
                  width={300}
                  height={100}
                  className="mx-auto transition-transform duration-300 hover:scale-105 filter brightness-0 invert"
                  priority
                />
              </div>
              <h1 className="text-4xl lg:text-6xl font-motiva font-bold text-white mb-2 tracking-normal lg:tracking-tight">
                THEODORO MELO ANDRADE COSTA
              </h1>
              <p className="text-xl lg:text-2xl text-white/80 font-light tracking-widest">ADVOGADOS ASSOCIADOS</p>
            </div>

            {/* CTA Button */}
            <div className="mb-12 animate-fade-in [animation-delay:0.2s] [animation-fill-mode:backwards]">
              <Button
                asChild
                size="lg"
                className="bg-white/10 backdrop-blur-sm border border-white/30 text-white hover:bg-white hover:text-slate-800 transition-all duration-300 px-8 py-3 text-lg"
              >
                <Link href="/contato">Entre em Contato</Link>
              </Button>
            </div>

            {/* Social Icons */}
            <div className="flex justify-center gap-6 animate-fade-in [animation-delay:0.2s] [animation-fill-mode:backwards]">
              <Link
                href="#"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white hover:text-slate-800 transition-all duration-300"
              >
                <Facebook className="w-5 h-5" />
              </Link>
              <Link
                 href="#"
                 className="w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white hover:text-slate-800 transition-all duration-300"
              >
                <Instagram className="w-5 h-5" />
              </Link>
              <Link
                href="#"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white hover:text-slate-800 transition-all duration-300"
              >
                <MessageCircle className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quem Somos Section */}
      <section className="py-24 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-white to-slate-50"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-slate-100 rounded-full filter blur-3xl opacity-30 -translate-x-1/2 -translate-y-1/2"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-slate-100 rounded-full filter blur-3xl opacity-40 translate-x-1/2 translate-y-1/2"></div>
        </div>

        {/* Subtle Pattern */}
        <div className="absolute inset-0 bg-grid-slate/[0.02] bg-[length:30px_30px]"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Imagem do Escritório */}
            <div className="animate-fade-in">
              <div className="relative group">
                {/* Main Image Container */}
                <div className="relative h-96 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl transform transition-all duration-500 group-hover:scale-[1.02]">
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-900/20 via-transparent to-slate-900/40 z-10"></div>
 <Image
        src="/images/Logotipo 1.jpg" // Substitua pelo caminho da sua imagem
        alt="Descrição da Imagem"
        layout="fill"
        objectFit="cover" 
        className="transition-transform duration-500 group-hover:scale-105"
        priority 
      />
                  {/* Floating Badge */}
                  <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg z-20">
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-slate-600" />
                      <span className="text-sm font-medium text-slate-800">21 Anos</span>
                    </div>
                  </div>
                </div>

                {/* Decorative Elements */}
                <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-gradient-to-br from-slate-500 to-slate-600 rounded-2xl opacity-10 transform rotate-12"></div>
                <div className="absolute -top-6 -left-6 w-16 h-16 bg-gradient-to-br from-slate-400 to-slate-500 rounded-xl opacity-10 transform -rotate-12"></div>
              </div>
            </div>

            {/* Conteúdo */}
            <div className="animate-fade-in [animation-delay:0.1s]">
              <div className="mb-8">
                <div className="inline-flex items-center gap-2 bg-slate-100 text-slate-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
                  <Target className="w-4 h-4" />
                  Sobre Nós
                </div>
                <h2 className="text-4xl lg:text-5xl font-motiva font-bold text-slate-800 mb-6 leading-tight">
                  Quem <span className="text-slate-600">somos</span>
                </h2>
                <div className="w-16 h-1 bg-gradient-to-r from-slate-500 to-slate-600 mb-8"></div>
              </div>

              <div className="space-y-6 text-lg text-slate-600 leading-relaxed mb-8">
                <p className="relative pl-6">
                  <span className="absolute left-0 top-2 w-2 h-2 bg-slate-500 rounded-full"></span>
                  Há <strong className="text-slate-800">21 anos</strong> defendemos e representamos pessoas e empresas
                  no âmbito judicial e extrajudicial em questões relacionadas ao direito empresarial, trabalhista,
                  previdenciário, familiar, sucessório e consumerista.
                </p>
                <p className="relative pl-6">
                  <span className="absolute left-0 top-2 w-2 h-2 bg-slate-500 rounded-full"></span>A{" "}
                  <strong className="text-slate-800">Theodoro & Melo Advogados Associados</strong> atua em todo o Brasil
                  tendo como sócios os advogados Brian Curts de Souza Theodoro e Vitor Hugo de Melo, profissionais com
                  vasta experiência e reconhecimento no mercado jurídico.
                </p>
                <p className="relative pl-6">
                  <span className="absolute left-0 top-2 w-2 h-2 bg-slate-500 rounded-full"></span>
                  Nossa <strong className="text-slate-800">missão</strong> é oferecer soluções jurídicas eficazes e
                  personalizadas, sempre pautadas na ética, transparência e excelência técnica, construindo
                  relacionamentos duradouros com nossos clientes.
                </p>
              </div>

              {/* Key Points */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                {[
                  { icon: CheckCircle, label: "Excelência", value: "Técnica" },
                  { icon: Users, label: "Atendimento", value: "Personalizado" },
                  { icon: Shield, label: "Ética", value: "Profissional" },
                ].map((point, index) => (
                  <div key={index} className="text-center group">
                    <div className="w-12 h-12 bg-gradient-to-br from-slate-100 to-slate-200 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-300">
                      <point.icon className="w-6 h-6 text-slate-600" />
                    </div>
                    <div className="text-sm font-medium text-slate-800">{point.label}</div>
                    <div className="text-xs text-slate-600">{point.value}</div>
                  </div>
                ))}
              </div>

              {/* CTA Button */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-[#0b3a48] hover:bg-[#1a4a60] text-white transition-all duration-300 px-6 py-3 rounded-xl shadow-lg hover:shadow-xl"
                >
                  <Link href="/sobre" className="flex items-center gap-2">
                    Nossa História Completa
                    <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-slate-300 text-slate-700 hover:bg-slate-50 transition-all duration-300 px-6 py-3 rounded-xl"
                >
                  <Link href="/equipe">Conheça a Equipe</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Áreas de Atuação */}
      <section className="py-24 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-96 h-96 bg-slate-100 rounded-full filter blur-3xl opacity-20"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-slate-200 rounded-full filter blur-3xl opacity-30"></div>
        </div>

        {/* Subtle Grid Pattern */}
        <div className="absolute inset-0 bg-grid-slate/[0.03] bg-[length:20px_20px]"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-motiva font-bold text-slate-800 mb-6 leading-tight">Áreas de Atuação</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-slate-400 to-slate-600 mx-auto mb-6"></div>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Oferecemos assessoria jurídica especializada em diversas áreas do direito, sempre com foco na excelência e
              nos resultados
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Building2,
                title: "Direito Empresarial",
                description:
                  "Consultoria completa para empresas, desde a constituição até questões contratuais complexas e planejamento societário.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: TrendingUp,
                title: "Recuperação Judicial",
                description:
                  "Especialização em processos de recuperação judicial e extrajudicial para empresas em dificuldades financeiras.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: Heart,
                title: "Direito de Família",
                description:
                  "Acompanhamento sensível e eficaz em questões familiares delicadas, com abordagem humanizada.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: FileText,
                title: "Inventários",
                description:
                  "Condução especializada de processos de inventário e questões sucessórias, protegendo o patrimônio familiar.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: FileText,
                title: "Contratos",
                description:
                  "Elaboração, análise e negociação de contratos diversos, garantindo segurança jurídica e proteção dos interesses.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: Shield,
                title: "Demandas Indenizatórias",
                description:
                  "Representação especializada em ações indenizatórias, buscando a reparação justa por danos morais e materiais.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: Building2,
                title: "Posse e Propriedade de Imóveis",
                description:
                  "Assessoria completa em questões imobiliárias, desde aquisições até resolução de conflitos de posse e propriedade.",
                color: "from-slate-700 to-slate-800",
              },
              {
                icon: ShoppingCart,
                title: "Relações de Consumo",
                description:
                  "Proteção integral dos direitos do consumidor em relações de consumo, com foco na reparação efetiva de danos.",
                color: "from-slate-700 to-slate-800",
              },
            ].map((area, index) => (
              <div key={index} className="group relative animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                {/* Card Background with Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-slate-100 to-white rounded-xl shadow-lg transform transition-all duration-300 group-hover:scale-[1.02] group-hover:shadow-xl"></div>

                {/* Colored Border Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl p-[1px]">
                  <div className="absolute inset-0 bg-white rounded-xl"></div>
                </div>

                {/* Content */}
                <div className="relative p-8 h-full flex flex-col">
                  {/* Icon with Gradient Background */}
                  <div className="mb-6 relative flex items-center justify-center">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${area.color} opacity-10 absolute`}></div>
                    <area.icon className="w-8 h-8 text-slate-700 relative z-10 transition-transform duration-300 group-hover:scale-110" />
                  </div>

                  <h3 className="text-xl font-medium text-slate-800 mb-4 group-hover:text-slate-900">{area.title}</h3>
                  <p className="text-slate-600 leading-relaxed flex-grow">{area.description}</p>

                  {/* Learn More Link */}
                  <div className="mt-6 pt-4 border-t border-slate-100">
                    <Link
                      href={`/areas-de-atuacao#${area.title.toLowerCase().replace(/\s+/g, "-")}`}
                      className="inline-flex items-center text-sm font-medium text-slate-700 hover:text-slate-900 transition-colors"
                    >
                      Saiba mais
                      <ArrowRight className="ml-1 w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <Button
              asChild
              size="lg"
              className="bg-[#0b3a48] hover:bg-[#1a4a60] text-white transition-all duration-300 px-6 py-3 rounded-xl shadow-lg hover:shadow-xl"
            >
              <Link href="/areas-de-atuacao" className="flex items-center gap-2">
                Ver Todas as Áreas
                <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>


      {/* CTA Final */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl lg:text-5xl font-motiva font-bold text-slate-800 mb-6">
              Precisa de Assessoria Jurídica?
            </h2>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              Nossa equipe está pronta para analisar seu caso e oferecer a melhor solução jurídica para suas
              necessidades
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-[#0b3a48] hover:bg-[#1a4a60] text-white transition-all duration-300 px-6 py-3 rounded-xl shadow-lg hover:shadow-xl"
              >
                <Link href="/contato">Agendar Consulta</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-slate-300 text-slate-700 hover:bg-slate-800 hover:text-white px-8 py-3 transition-all duration-300"
              >
                <Link href="/sobre">Conhecer Nossa História</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
